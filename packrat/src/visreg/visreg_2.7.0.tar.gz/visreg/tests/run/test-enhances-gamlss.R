library(visreg)
f <- system.file('tests', 'enhances-gamlss.R', package='visreg')
source(f)
