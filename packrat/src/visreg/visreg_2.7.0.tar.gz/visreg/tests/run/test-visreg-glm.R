library(visreg)
f <- system.file('tests', 'visreg-glm.R', package='visreg')
source(f)
