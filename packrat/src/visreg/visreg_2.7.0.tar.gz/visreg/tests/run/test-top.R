library(visreg)
f <- system.file('tests', 'top.R', package='visreg')
source(f)
