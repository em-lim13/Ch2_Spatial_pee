library(visreg)
f <- system.file('tests', 'unusual-formulas.R', package='visreg')
source(f)
