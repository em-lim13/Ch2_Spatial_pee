library(visreg)
f <- system.file('tests', 'enhances-gamm4.R', package='visreg')
source(f)
