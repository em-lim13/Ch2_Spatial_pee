library(visreg)
f <- system.file('tests', 'enhances-nnet.R', package='visreg')
source(f)
