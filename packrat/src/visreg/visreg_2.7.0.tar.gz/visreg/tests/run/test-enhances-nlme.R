library(visreg)
f <- system.file('tests', 'enhances-nlme.R', package='visreg')
source(f)
