library(visreg)
f <- system.file('tests', 'enhances-betareg.R', package='visreg')
source(f)
