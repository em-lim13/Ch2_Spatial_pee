library(visreg)
f <- system.file('tests', 'ggplot.R', package='visreg')
source(f)
