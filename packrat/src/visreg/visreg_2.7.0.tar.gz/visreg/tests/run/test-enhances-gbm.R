library(visreg)
f <- system.file('tests', 'enhances-gbm.R', package='visreg')
source(f)
