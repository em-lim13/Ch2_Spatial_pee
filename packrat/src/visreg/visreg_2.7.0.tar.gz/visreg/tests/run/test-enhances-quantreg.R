library(visreg)
f <- system.file('tests', 'enhances-quantreg.R', package='visreg')
source(f)
