library(visreg)
f <- system.file('tests', 'visreg2d-glm.R', package='visreg')
source(f)
