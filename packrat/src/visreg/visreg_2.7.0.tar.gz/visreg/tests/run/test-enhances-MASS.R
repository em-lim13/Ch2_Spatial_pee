library(visreg)
f <- system.file('tests', 'enhances-MASS.R', package='visreg')
source(f)
