library(visreg)
f <- system.file('tests', 'enhances-svm.R', package='visreg')
source(f)
