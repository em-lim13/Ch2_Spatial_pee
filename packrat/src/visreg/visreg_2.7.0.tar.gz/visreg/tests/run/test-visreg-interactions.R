library(visreg)
f <- system.file('tests', 'visreg-interactions.R', package='visreg')
source(f)
