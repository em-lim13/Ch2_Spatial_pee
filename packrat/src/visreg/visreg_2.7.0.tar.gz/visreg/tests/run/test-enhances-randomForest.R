library(visreg)
f <- system.file('tests', 'enhances-randomForest.R', package='visreg')
source(f)
