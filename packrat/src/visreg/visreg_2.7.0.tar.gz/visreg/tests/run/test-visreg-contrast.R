library(visreg)
f <- system.file('tests', 'visreg-contrast.R', package='visreg')
source(f)
