library(visreg)
f <- system.file('tests', 'enhances-loess.R', package='visreg')
source(f)
