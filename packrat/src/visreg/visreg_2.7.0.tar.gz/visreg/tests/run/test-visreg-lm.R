library(visreg)
f <- system.file('tests', 'visreg-lm.R', package='visreg')
source(f)
