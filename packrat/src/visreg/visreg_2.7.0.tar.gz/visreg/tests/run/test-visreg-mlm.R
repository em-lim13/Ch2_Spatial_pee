library(visreg)
f <- system.file('tests', 'visreg-mlm.R', package='visreg')
source(f)
