library(visreg)
f <- system.file('tests', 'visreg-coxph.R', package='visreg')
source(f)
