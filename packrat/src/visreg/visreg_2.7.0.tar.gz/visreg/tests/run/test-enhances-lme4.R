library(visreg)
f <- system.file('tests', 'enhances-lme4.R', package='visreg')
source(f)
