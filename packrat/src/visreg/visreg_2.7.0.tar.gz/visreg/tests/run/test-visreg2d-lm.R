library(visreg)
f <- system.file('tests', 'visreg2d-lm.R', package='visreg')
source(f)
