library(visreg)
f <- system.file('tests', 'missing-data.R', package='visreg')
source(f)
