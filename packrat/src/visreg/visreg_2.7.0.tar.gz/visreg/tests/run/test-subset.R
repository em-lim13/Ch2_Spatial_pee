library(visreg)
f <- system.file('tests', 'subset.R', package='visreg')
source(f)
